document.getElementById("name").textContent = settings.name
document.getElementById("desc").textContent = settings.desc
document.getElementById("dev").textContent = "by " + credits.dev
if (credits.hadCo_dev == true) {
    document.getElementById("co_dev").textContent = "and " + credits.co_dev
} else if (credits.hadCo_dev == false) {
    document.getElementById("co_dev").textContent = ""
} else {
    document.getElementById("co_dev").textContent = ""
    console.error("ERROR: PLEASE CHANGE CO_DEV IN DATA.JS .")
}
document.getElementById("context").textContent = settings.context